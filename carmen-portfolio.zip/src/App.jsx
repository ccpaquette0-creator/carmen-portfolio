export default function App() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-100">
      <h1 className="text-4xl font-bold text-slate-800">
        Hello from Carmen’s Portfolio 🚀
      </h1>
    </main>
  );
}